(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const el = {
    groupSearch: $('#groupSearch'), groupList: $('#groupList'), groupsCount: $('#groupsCount'),
    selectedGroupTitle: $('#selectedGroupTitle'), scheduleSubtitle: $('#scheduleSubtitle'),
    scheduleContent: $('#scheduleContent'), scheduleMeta: $('#scheduleMeta'), weekLabel: $('#weekLabel'),
    weekDateRange: $('#weekDateRange'), updatedAt: $('#updatedAt'), previousWeek: $('#previousWeek'),
    nextWeek: $('#nextWeek'), todayButton: $('#todayButton'), refreshButton: $('#refreshButton'),
    themeToggle: $('#themeToggle'), sourceStatus: $('#sourceStatus'), toastRegion: $('#toastRegion')
  };

  const DAY_NAMES = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];
  const state = {
    groups: [], selectedGroup: null, groupData: null, weeks: [], weekIndex: 0,
    loadingGroup: false, refreshing: false, forceNextSelection: false, searchTimer: null, cacheUpdatedAt: null
  };

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);

  async function api(url, options = {}) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 30_000);
    try {
      const response = await fetch(url, {
        ...options,
        signal: options.signal || controller.signal,
        headers: { Accept: 'application/json', ...(options.headers || {}) },
        cache: 'no-store'
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = new Error(payload.detail || payload.error || `Ошибка запроса (${response.status})`);
        error.status = response.status;
        throw error;
      }
      return payload;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('Сервер не ответил за 30 секунд. Проверь адрес развёрнутого сайта и API.');
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  function toast(message, type = '') {
    const node = document.createElement('div');
    node.className = `toast${type ? ` ${type}` : ''}`;
    node.textContent = message;
    el.toastRegion.append(node);
    window.setTimeout(() => node.remove(), 4200);
  }

  function setSourceStatus(text, mode = '') {
    el.sourceStatus.classList.remove('is-online', 'is-error', 'online', 'offline');
    if (mode === 'online') el.sourceStatus.classList.add('is-online', 'online');
    if (mode === 'error') el.sourceStatus.classList.add('is-error', 'offline');
    const label = el.sourceStatus.querySelector('span');
    if (label) label.textContent = text;
    el.sourceStatus.setAttribute('aria-label', text);
  }

  function setTheme(theme) {
    const resolved = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.dataset.theme = resolved;
    try { localStorage.setItem('ufabist-theme', resolved); } catch { /* хранилище может быть отключено */ }
    el.themeToggle.setAttribute('aria-label', resolved === 'dark' ? 'Включить светлую тему' : 'Включить тёмную тему');
    el.themeToggle.title = el.themeToggle.getAttribute('aria-label');
  }

  function initTheme() {
    let saved = null;
    try { saved = localStorage.getItem('ufabist-theme'); } catch { /* используем системную тему */ }
    const systemDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    setTheme(saved || (systemDark ? 'dark' : 'light'));
  }

  function localDateFromIso(value) {
    if (!value) return null;
    const match = String(value).match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (!match) return null;
    const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function parseShortDate(value, reference = new Date()) {
    if (!value) return null;
    const match = String(value).match(/^(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?$/);
    if (!match) return localDateFromIso(value);
    let year = match[3] ? Number(match[3]) : reference.getFullYear();
    if (year < 100) year += 2000;
    let date = new Date(year, Number(match[2]) - 1, Number(match[1]));
    if (!match[3]) {
      const distance = date.getTime() - reference.getTime();
      if (distance > 183 * 86400000) date = new Date(year - 1, date.getMonth(), date.getDate());
      else if (distance < -183 * 86400000) date = new Date(year + 1, date.getMonth(), date.getDate());
    }
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function dateKey(date) {
    if (!date) return '';
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  function formatDate(date) {
    return date ? new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' }).format(date) : '';
  }

  function formatDateRange(week) {
    const start = parseShortDate(week?.start);
    const end = parseShortDate(week?.end, start || new Date());
    if (start && end) return `${formatDate(start)} — ${formatDate(end)}`;
    if (start) return `С ${formatDate(start)}`;
    if (end) return `До ${formatDate(end)}`;
    return week?.label || (week?.number ? `Неделя ${week.number}` : 'Учебная неделя');
  }

  function getCurrentWeekIndex(weeks) {
    const today = new Date();
    const todayKey = dateKey(today);
    const matching = weeks.findIndex((week) => {
      const start = parseShortDate(week.start);
      const end = parseShortDate(week.end, start || today);
      return start && end && today >= start && today <= new Date(end.getFullYear(), end.getMonth(), end.getDate(), 23, 59, 59);
    });
    if (matching >= 0) return matching;
    const preceding = weeks.map((week, index) => ({ index, start: parseShortDate(week.start) }))
      .filter((item) => item.start && dateKey(item.start) <= todayKey)
      .sort((a, b) => b.start - a.start)[0];
    return preceding ? preceding.index : 0;
  }

  function renderGroupList() {
    const query = el.groupSearch.value.trim().toLocaleLowerCase('ru-RU');
    const filtered = state.groups.filter((group) => group.name.toLocaleLowerCase('ru-RU').includes(query));
    el.groupsCount.textContent = String(state.groups.length);
    if (!filtered.length) {
      el.groupList.innerHTML = '<div class="empty-state"><h3>Группы не найдены</h3><p>Измени поисковый запрос.</p></div>';
      return;
    }
    el.groupList.innerHTML = filtered.map((group) => {
      const active = group.name === state.selectedGroup;
      const detail = group.lessonsCount
        ? `${group.weeksCount} нед. · ${group.lessonsCount} пар`
        : `${group.weeksCount || 'PDF'} нед. · загрузить расписание`;
      return `<button class="group-item${active ? ' active' : ''}" type="button" data-group="${escapeHtml(group.name)}" aria-current="${active ? 'true' : 'false'}">
        <span><strong>${escapeHtml(group.name)}</strong><br><small>${escapeHtml(detail)}</small></span>
        <span class="group-count">${group.lessonsCount || '↗'}</span>
      </button>`;
    }).join('');
  }

  function renderGroupSkeleton() {
    el.groupList.innerHTML = '<div class="group-skeleton"></div><div class="group-skeleton"></div><div class="group-skeleton"></div><div class="group-skeleton"></div>';
  }

  function renderScheduleSkeleton() {
    el.scheduleContent.setAttribute('aria-busy', 'true');
    el.scheduleContent.innerHTML = '<div class="schedule-loading"><div class="schedule-skeleton"></div><div class="schedule-skeleton"></div><div class="schedule-skeleton"></div><div class="schedule-skeleton"></div></div>';
  }

  function renderError(title, message) {
    el.scheduleContent.setAttribute('aria-busy', 'false');
    el.scheduleContent.innerHTML = `<div class="error-state"><h3>${escapeHtml(title)}</h3><p>${escapeHtml(message)}</p></div>`;
  }

  async function loadGroups({ preserveSelection = true } = {}) {
    const previous = preserveSelection ? state.selectedGroup : null;
    renderGroupSkeleton();
    try {
      const data = await api('/api/groups');
      state.groups = Array.isArray(data.groups) ? data.groups : [];
      state.cacheUpdatedAt = data.updatedAt || null;
      renderGroupList();
      if (!state.groups.length) {
        setSourceStatus('Нет данных', 'error');
        renderError('Расписание пока пустое', 'Сервер ещё не получил расписание. Попробуй обновить данные.');
        return;
      }
      setSourceStatus(data.stale ? 'Последний сохранённый кэш' : 'Данные доступны', data.stale ? 'error' : 'online');
      const nextGroup = state.groups.some((group) => group.name === previous) ? previous : state.groups[0].name;
      if (nextGroup) {
        const force = state.forceNextSelection;
        state.forceNextSelection = false;
        await selectGroup(nextGroup, { force });
      }
    } catch (error) {
      setSourceStatus('Сервер недоступен', 'error');
      el.groupList.innerHTML = '<div class="empty-state"><h3>Не удалось загрузить группы</h3><p>Проверь, запущен ли сервер, и обнови страницу.</p></div>';
      renderError('Не удалось получить расписание', error.message);
    }
  }

  async function selectGroup(groupName, { force = false } = {}) {
    if (!groupName || state.loadingGroup) return;
    state.loadingGroup = true;
    state.selectedGroup = groupName;
    renderGroupList();
    el.selectedGroupTitle.textContent = groupName;
    el.scheduleSubtitle.textContent = 'Загружаем расписание выбранной группы…';
    renderScheduleSkeleton();
    try {
      const suffix = force ? '?refresh=1' : '';
      const data = await api(`/api/groups/${encodeURIComponent(groupName)}${suffix}`);
      state.groupData = data.group || null;
      state.weeks = Array.isArray(state.groupData?.weeks) ? state.groupData.weeks : [];
      if (!state.weeks.length) {
        state.weekIndex = 0;
        updateWeekControls();
        renderError('Расписание не найдено', 'Для этой группы пока нет опубликованных недель.');
        return;
      }
      state.weekIndex = getCurrentWeekIndex(state.weeks);
      renderSchedule();
    } catch (error) {
      renderError('Не удалось загрузить группу', error.message);
      toast(error.message, 'error');
    } finally {
      state.loadingGroup = false;
      renderGroupList();
    }
  }

  function parseTimeRange(value) {
    const match = String(value || '').match(/(\d{1,2}):(\d{2})\s*[-–—]\s*(\d{1,2}):(\d{2})/);
    if (!match) return null;
    return { start: Number(match[1]) * 60 + Number(match[2]), end: Number(match[3]) * 60 + Number(match[4]) };
  }

  function isCurrentLesson(entry, today, nowMinutes) {
    const entryDate = localDateFromIso(entry.date);
    const isToday = entryDate ? dateKey(entryDate) === dateKey(today) : entry.day === DAY_NAMES[today.getDay()];
    const range = parseTimeRange(entry.time);
    return Boolean(isToday && range && nowMinutes >= range.start && nowMinutes < range.end);
  }

  function dayKeyFor(entry) {
    const date = localDateFromIso(entry.date);
    if (date) return dateKey(date);
    return String(entry.day || 'Занятия без даты');
  }

  function daySortValue(day) {
    const date = localDateFromIso(day.date);
    if (date) return date.getTime();
    const index = DAY_NAMES.indexOf(day.name);
    return index >= 0 ? index * 86400000 : 8 * 86400000;
  }

  function renderLesson(entry, nowInfo) {
    const current = isCurrentLesson(entry, nowInfo.today, nowInfo.minutes);
    const subject = entry.subject || 'Занятие';
    const time = String(entry.time || 'Время не указано').replace(/\s*[-–—]\s*/, ' — ');
    const teacher = entry.teacher ? `<div class="lesson-teacher"><span aria-hidden="true">◉</span>${escapeHtml(entry.teacher)}</div>` : '';
    const room = entry.room ? `<div class="lesson-room"><span aria-hidden="true">⌖</span>Аудитория ${escapeHtml(entry.room)}</div>` : '';
    return `<article class="lesson-card${current ? ' current is-current' : ''}">
      <div class="lesson-top"><span class="lesson-time">${escapeHtml(time)}</span><span class="lesson-number">ПАРА ${escapeHtml(entry.lesson ?? '—')}</span></div>
      <h4 class="lesson-title">${escapeHtml(subject)}</h4>
      <div class="lesson-details">${teacher}${room}</div>
      ${current ? '<span class="current-label">Сейчас идёт</span>' : ''}
    </article>`;
  }

  function renderSchedule() {
    const week = state.weeks[state.weekIndex];
    if (!week) return;
    const entries = Array.isArray(week.entries) ? week.entries : [];
    const today = new Date();
    const nowInfo = { today, minutes: today.getHours() * 60 + today.getMinutes() };
    const buckets = new Map();

    for (const entry of entries) {
      const key = dayKeyFor(entry);
      if (!buckets.has(key)) {
        const date = localDateFromIso(entry.date);
        buckets.set(key, { key, date, name: entry.day || (date ? DAY_NAMES[date.getDay()] : 'Занятия'), entries: [] });
      }
      buckets.get(key).entries.push(entry);
    }

    // Для недель с датами показываем все календарные дни периода, даже если в отдельный день пар нет.
    const weekStart = parseShortDate(week.start);
    const weekEnd = parseShortDate(week.end, weekStart || new Date());
    if (weekStart && weekEnd) {
      const cursor = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate());
      const end = new Date(weekEnd.getFullYear(), weekEnd.getMonth(), weekEnd.getDate());
      for (let guard = 0; cursor <= end && guard < 7; guard += 1) {
        const key = dateKey(cursor);
        if (!buckets.has(key)) buckets.set(key, { key, date: new Date(cursor), name: DAY_NAMES[cursor.getDay()], entries: [] });
        cursor.setDate(cursor.getDate() + 1);
      }
    }
    const days = [...buckets.values()].sort((a, b) => daySortValue(a) - daySortValue(b));
    for (const day of days) day.entries.sort((a, b) => {
      const lessonDiff = (Number(a.lesson) || 99) - (Number(b.lesson) || 99);
      return lessonDiff || String(a.time || '').localeCompare(String(b.time || ''));
    });
    const groupsCurrent = days.some((day) => day.entries.some((entry) => isCurrentLesson(entry, today, nowInfo.minutes)));

    el.scheduleContent.setAttribute('aria-busy', 'false');
    if (!entries.length) {
      el.scheduleContent.innerHTML = '<div class="empty-state"><h3>На этой неделе пар нет</h3><p>Выбери другую неделю или проверь расписание позже.</p></div>';
    } else {
      el.scheduleContent.innerHTML = `<div class="days-grid">${days.map((day) => {
        const isToday = day.date ? dateKey(day.date) === dateKey(today) : day.name === DAY_NAMES[today.getDay()];
        const dayTitle = day.date ? DAY_NAMES[day.date.getDay()] : day.name;
        const dateLabel = day.date ? formatDate(day.date) : '';
        return `<section class="day-card${isToday ? ' today is-today' : ''}">
          <header class="day-header"><strong>${escapeHtml(dayTitle)}</strong><time>${escapeHtml(dateLabel)}</time></header>
          <div class="lesson-list">${day.entries.length ? day.entries.map((entry) => renderLesson(entry, nowInfo)).join('') : '<p class="empty-day">Занятий нет</p>'}</div>
        </section>`;
      }).join('')}</div>`;
    }

    el.scheduleSubtitle.textContent = `${week.program ? `${week.program} · ` : ''}Расписание по учебной неделе`;
    updateWeekControls();
    el.weekDateRange.textContent = `${entries.length} ${pluralize(entries.length, ['пара', 'пары', 'пар'])}`;
    el.updatedAt.textContent = state.cacheUpdatedAt ? `Обновлено: ${formatDateTime(state.cacheUpdatedAt)}` : ''; 
    if (groupsCurrent) setSourceStatus('Идёт текущая пара', 'online');
  }

  function pluralize(number, forms) {
    const n = Math.abs(number) % 100;
    const n1 = n % 10;
    if (n > 10 && n < 20) return forms[2];
    if (n1 > 1 && n1 < 5) return forms[1];
    if (n1 === 1) return forms[0];
    return forms[2];
  }

  function formatDateTime(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
  }

  function updateWeekControls() {
    const week = state.weeks[state.weekIndex];
    el.weekLabel.textContent = week ? (week.label || `Неделя ${week.number || state.weekIndex + 1}`) : 'Неделя не выбрана';
    el.weekDateRange.textContent = week ? formatDateRange(week) : 'Выбери учебную группу слева';
    el.previousWeek.disabled = state.weekIndex <= 0;
    el.nextWeek.disabled = state.weekIndex >= state.weeks.length - 1;
    el.todayButton.disabled = !state.weeks.length;
  }

  async function refreshSchedule() {
    if (state.refreshing) return;
    state.refreshing = true;
    el.refreshButton.disabled = true;
    el.refreshButton.classList.add('is-loading');
    const label = el.refreshButton.querySelector('span');
    if (label) label.textContent = 'Обновление…';
    try {
      const result = await api('/api/refresh', { method: 'POST' });
      if (result.queued) {
        toast(result.message || 'Синхронизация запущена. Данные появятся после её завершения.', 'success');
        setSourceStatus('Синхронизация запущена', '');
        return;
      }
      toast(result.message || 'Показаны последние сохранённые данные.', 'success');
      setSourceStatus('Последний сохранённый кэш', '');
    } catch (error) {
      toast(error.status === 429 ? 'Обновление недавно выполнялось. Попробуй чуть позже.' : 'Источник недоступен. Оставлены последние сохранённые данные.', 'error');
      try {
        await loadGroups({ preserveSelection: true });
        setSourceStatus('Показан сохранённый кэш', 'error');
      } catch { setSourceStatus('Нет соединения', 'error'); }
    } finally {
      state.refreshing = false;
      el.refreshButton.disabled = false;
      el.refreshButton.classList.remove('is-loading');
      if (label) label.textContent = 'Обновить';
    }
  }

  function bindEvents() {
    el.groupSearch.addEventListener('input', () => {
      window.clearTimeout(state.searchTimer);
      state.searchTimer = window.setTimeout(renderGroupList, 100);
    });
    el.groupList.addEventListener('click', (event) => {
      const button = event.target.closest('[data-group]');
      if (button) selectGroup(button.dataset.group);
    });
    el.previousWeek.addEventListener('click', () => {
      if (state.weekIndex > 0) { state.weekIndex -= 1; renderSchedule(); }
    });
    el.nextWeek.addEventListener('click', () => {
      if (state.weekIndex < state.weeks.length - 1) { state.weekIndex += 1; renderSchedule(); }
    });
    el.todayButton.addEventListener('click', () => {
      state.weekIndex = getCurrentWeekIndex(state.weeks);
      renderSchedule();
    });
    el.refreshButton.addEventListener('click', refreshSchedule);
    el.themeToggle.addEventListener('click', () => {
      setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) {
        event.preventDefault();
        el.groupSearch.focus();
      }
      if (event.key === 'Escape' && document.activeElement === el.groupSearch) {
        el.groupSearch.value = '';
        renderGroupList();
        el.groupSearch.blur();
      }
    });
  }

  async function init() {
    initTheme();
    bindEvents();
    try {
      const health = await api('/api/health');
      if (!health.cacheAvailable) setSourceStatus('Загрузка расписания', '');
      else setSourceStatus(health.stale ? 'Последний сохранённый кэш' : 'Данные доступны', health.stale ? 'error' : 'online');
    } catch { setSourceStatus('Проверяем соединение', ''); }
    await loadGroups({ preserveSelection: false });
  }

  init();
})();
