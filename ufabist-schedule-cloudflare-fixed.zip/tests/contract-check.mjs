import fs from 'node:fs';
import assert from 'node:assert/strict';

const root = new URL('../', import.meta.url);
const read = path => fs.readFileSync(new URL(path, root), 'utf8');
const worker = read('src/worker.js');
const client = read('public/app.js');
const html = read('public/index.html');
const parser = read('src/parser.js');
const wrangler = JSON.parse(read('wrangler.jsonc'));
const workflow = read('.github/workflows/sync-schedule.yml');

for (const route of ["'/api/health'", "'/api/groups'", "'/api/refresh'"]) {
  assert.ok(worker.includes(route), `Missing Worker route ${route}`);
}
assert.ok(worker.includes("url.pathname.startsWith('/api/groups/')"), 'Missing group details route');
assert.ok(client.includes("api('/api/groups')"), 'Client catalog endpoint does not match Worker');
assert.ok(client.includes("api('/api/refresh'"), 'Client refresh endpoint does not match Worker');
assert.ok(client.includes('/api/groups/${encodeURIComponent(groupName)}'), 'Client group endpoint does not match Worker');
assert.ok(parser.includes('export async function discoverCatalog'), 'Catalog parser export missing');
assert.ok(parser.includes('export async function getGroupSchedule'), 'Group parser export missing');
assert.ok(parser.includes('assignWeekDatesToBlocks'), 'Week date block mapping is missing');
assert.ok(parser.includes('dedupeScheduleEntries'), 'Exact duplicate filtering is missing');
assert.ok(parser.includes('function nearbyWeekCaption'), 'Week headings must be read near PDF links, not only from anchor parents');
assert.ok(parser.includes('node.prevAll()'), 'Parser must inspect the preceding week heading');
assert.ok(parser.includes('blocks.length !== expectedWeekDates.length'), 'Parser must reject partial one-page day blocks instead of mislabeling them');
assert.ok(worker.includes('cacheAvailable:'), 'Health endpoint must report cache availability for the existing frontend');
assert.ok(worker.includes('match.stale'), 'Group endpoint must respect stale catalog entries');
assert.ok(client.includes('Занятий нет'), 'Empty days in the selected week must remain visible');
assert.ok(client.includes('result.queued'), 'Refresh UI must distinguish queued sync from completed update');
assert.equal(wrangler.name, 'ufabist');
assert.equal(wrangler.main, 'src/worker.js');
assert.equal(wrangler.assets.directory, './public');
assert.ok(workflow.includes('workflow_dispatch:'), 'Manual schedule sync workflow is missing');
assert.ok(workflow.includes('schedule:'), 'Scheduled synchronization is missing');
assert.ok(html.includes('href="/style.css"') && html.includes('src="/app.js"'), 'Static asset paths are incorrect');
console.log('Cloudflare/API contract check passed.');
