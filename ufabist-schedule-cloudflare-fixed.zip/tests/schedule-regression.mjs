import assert from 'node:assert/strict';
import { weekDatesFromMeta, assignWeekDatesToBlocks, dayNameFromIso, dedupeScheduleEntries } from '../src/schedule-utils.js';

const meta = { start: '16.11', end: '21.11', week: 12, label: '12 неделя' };
const sourceText = 'РАСПИСАНИЕ занятий на первый семестр 2026-2027 учебного года; Понедельник 16.11.26г.; Суббота 21.11.26г.';
const dates = weekDatesFromMeta(meta, sourceText, new Date('2026-11-16T12:00:00Z'));
assert.deepEqual(dates, [
  '2026-11-16', '2026-11-17', '2026-11-18',
  '2026-11-19', '2026-11-20', '2026-11-21'
]);
assert.deepEqual(dates.map(dayNameFromIso), [
  'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'
]);
const blocks = Array.from({ length: 6 }, () => ({}));
assert.equal(assignWeekDatesToBlocks(blocks, meta, sourceText, new Date('2026-11-16T12:00:00Z')), true);
assert.deepEqual(blocks.map(block => [block.date, block.day]), dates.map((date, index) => [date, ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'][index]]));
assert.equal(assignWeekDatesToBlocks([{}, {}], meta, sourceText), false, 'Range must not be forced onto a mismatched block count');
assert.deepEqual(weekDatesFromMeta({ start: '31.02', end: '07.03' }, sourceText), [], 'Invalid calendar dates must be rejected');

// Регрессионный набор по официальному PDF ИСД-12-нед: по первой колонке ИСД-21.
const expectedCounts = [2, 4, 3, 3, 4, 2];
const entries = [];
for (let dayIndex = 0; dayIndex < expectedCounts.length; dayIndex += 1) {
  for (let lesson = 1; lesson <= expectedCounts[dayIndex]; lesson += 1) {
    entries.push({
      group: 'ИСД-21', date: dates[dayIndex], day: dayNameFromIso(dates[dayIndex]),
      lesson, time: `${8 + lesson}:30-${10 + lesson}:00`,
      subject: `Предмет ${dayIndex + 1}-${lesson}`, teacher: 'Тест Т.Т.', room: '201'
    });
  }
}
// Один полностью совпадающий повтор должен исчезнуть; параллельный предмет в то же время — остаться.
entries.push({ ...entries[0] });
entries.push({ ...entries[0], subject: 'Другой предмет' });
const unique = dedupeScheduleEntries(entries);
assert.equal(unique.length, 19);
assert.equal(unique.filter(item => item.date === '2026-11-16').length, 3);
assert.equal(unique.filter(item => item.date === '2026-11-17').length, 4);
assert.deepEqual(
  dates.map(date => unique.filter(item => item.date === date).length),
  [3, 4, 3, 3, 4, 2]
);
console.log('Schedule regression checks passed: six sequential days, duplicate-only dedupe, 19 retained rows.');
