import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { discoverCatalog, getGroupSchedule, canonicalGroup, SOURCE_URL } from '../src/parser.js';
import { dayNameFromIso } from '../src/schedule-utils.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA_DIR = path.join(ROOT, 'public', 'data');
const SCHEDULE_DIR = path.join(DATA_DIR, 'schedules');
const RUN_DEADLINE = Date.now() + 25 * 60 * 1000;

const groupId = name => Buffer.from(canonicalGroup(name), 'utf8').toString('hex');
const readJson = async file => {
  try { return JSON.parse(await fs.readFile(file, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
};
const writeJson = async (file, value) => {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.tmp`;
  await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
  await fs.rename(temporary, file);
};

function assertScheduleShape(schedule) {
  if (!schedule || !Array.isArray(schedule.weeks) || !schedule.weeks.length) throw new Error('В PDF не найдено ни одной недели с занятиями.');
  const count = schedule.weeks.reduce((sum, week) => sum + (week.entries?.length || 0), 0);
  if (!count) throw new Error('В расписании нет распознанных занятий.');
  for (const week of schedule.weeks) {
    if (!Array.isArray(week.entries)) throw new Error(`Неделя ${week.number} не содержит массива занятий.`);
    for (const entry of week.entries) {
      if (!entry.date || !/^\d{4}-\d{2}-\d{2}$/.test(entry.date)) throw new Error(`Найдена пара без корректной даты (неделя ${week.number}).`);
      if (dayNameFromIso(entry.date) !== entry.day) throw new Error(`Не совпадает день и дата: ${entry.day} / ${entry.date}.`);
      if (!entry.subject || !entry.time) throw new Error(`Найдена неполная запись занятия (${entry.date}).`);
    }
  }
  return count;
}

// Регрессия по текущему официальному PDF ИСД-12-нед: только колонка ИСД-21.
// Если институт меняет этот исторический PDF, предупреждение фиксируется, но остальные группы синхронизируются.
function checkIsdWeek12(schedule) {
  if (canonicalGroup(schedule.name) !== 'ИСД-21') return null;
  const week = schedule.weeks.find(item => Number(item.number) === 12 && item.start === '16.11' && item.end === '21.11');
  if (!week) return null;
  const dates = ['2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20', '2026-11-21'];
  const expected = [2, 4, 3, 3, 4, 2];
  const actual = dates.map(date => week.entries.filter(entry => entry.date === date).length);
  if (actual.some((count, index) => count !== expected[index])) {
    throw new Error(`Регрессионная проверка ИСД-21 / 12 неделя не пройдена: ожидалось ${expected.join('/')}, получено ${actual.join('/')}. Старый кэш сохранён.`);
  }
  return { dates, lessonsPerDay: actual, total: actual.reduce((sum, value) => sum + value, 0) };
}

await fs.mkdir(SCHEDULE_DIR, { recursive: true });
const previousCatalog = await readJson(path.join(DATA_DIR, 'catalog.json'));
const catalog = await discoverCatalog({ force: true, deadline: RUN_DEADLINE, previous: previousCatalog });
if (!Array.isArray(catalog.groups) || !catalog.groups.length) throw new Error('Источник не вернул ни одной учебной группы. Последний каталог не изменён.');

const errors = [];
const resultGroups = [];
let successfulGroups = 0;
let totalLessons = 0;
let isdRegression = null;

for (const sourceGroup of catalog.groups) {
  const id = groupId(sourceGroup.name);
  const file = path.join(SCHEDULE_DIR, `${id}.json`);
  let schedule = null;
  let stale = false;
  try {
    schedule = await getGroupSchedule(sourceGroup.name, catalog, { force: true, deadline: RUN_DEADLINE });
    const count = assertScheduleShape(schedule);
    isdRegression = checkIsdWeek12(schedule) || isdRegression;
    schedule.updatedAt = new Date().toISOString();
    schedule.stale = false;
    await writeJson(file, schedule);
    successfulGroups += 1;
    totalLessons += count;
  } catch (error) {
    stale = true;
    const oldSchedule = await readJson(file);
    if (oldSchedule?.weeks?.length) {
      schedule = { ...oldSchedule, stale: true };
      totalLessons += oldSchedule.weeks.reduce((sum, week) => sum + (week.entries?.length || 0), 0);
    }
    errors.push({ group: sourceGroup.name, message: String(error.message || error).slice(0, 240), keptPrevious: Boolean(schedule) });
    console.error(`[sync] ${sourceGroup.name}: ${error.message || error}`);
  }

  resultGroups.push({
    name: sourceGroup.name,
    id,
    program: sourceGroup.program,
    pageUrl: sourceGroup.pageUrl,
    weekLinks: sourceGroup.weekLinks || [],
    weeksCount: schedule?.weeks?.length || sourceGroup.weekLinks?.length || 0,
    lessonsCount: schedule?.weeks?.reduce((sum, week) => sum + (week.entries?.length || 0), 0) || 0,
    stale
  });
}

if (!successfulGroups && !previousCatalog?.groups?.length) throw new Error('Не удалось сохранить расписание ни одной группы; новых данных нет.');
const updatedAt = new Date().toISOString();
const outputCatalog = {
  source: SOURCE_URL,
  updatedAt,
  partial: errors.length > 0,
  groups: resultGroups.sort((a, b) => a.name.localeCompare(b.name, 'ru'))
};
const metadata = {
  service: 'ufabist-schedule',
  updatedAt,
  source: SOURCE_URL,
  groupCount: resultGroups.length,
  successfulGroups,
  totalLessons,
  partial: errors.length > 0,
  errors,
  isdWeek12Regression: isdRegression
};

await writeJson(path.join(DATA_DIR, 'catalog.json'), outputCatalog);
await writeJson(path.join(DATA_DIR, 'metadata.json'), metadata);
console.log(JSON.stringify({
  updatedAt,
  groups: resultGroups.length,
  successfulGroups,
  totalLessons,
  failedGroups: errors.length,
  isdWeek12Regression: isdRegression
}, null, 2));
