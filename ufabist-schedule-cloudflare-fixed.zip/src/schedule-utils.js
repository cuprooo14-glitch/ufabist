const DAY_NAMES = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];

function parseDayMonth(value) {
  const match = String(value || '').match(/^(\d{1,2})\.(\d{1,2})$/);
  if (!match) return null;
  const day = Number(match[1]);
  const month = Number(match[2]);
  if (day < 1 || day > 31 || month < 1 || month > 12) return null;
  return { day, month };
}

function inferYear(text, startMonth, now = new Date()) {
  const academic = String(text || '').match(/\b(20\d{2})\s*[-–—/]\s*(20\d{2})\b/);
  if (academic) return startMonth >= 8 ? Number(academic[1]) : Number(academic[2]);

  const years = [...String(text || '').matchAll(/\b\d{1,2}\.\d{1,2}\.(\d{2,4})\b/g)]
    .map(match => Number(match[1].length === 2 ? `20${match[1]}` : match[1]))
    .filter(year => year >= 2020 && year <= 2100);
  if (years.length) {
    const counts = new Map();
    for (const year of years) counts.set(year, (counts.get(year) || 0) + 1);
    return [...counts].sort((a, b) => b[1] - a[1])[0][0];
  }
  return now.getFullYear();
}

/**
 * Возвращает даты всех дней учебной недели в календарном порядке.
 * Для PDF УфаБИСТ даты периода в подписи ссылки — более надёжный источник,
 * чем координаты вертикально повёрнутых надписей в левом столбце таблицы.
 */
export function weekDatesFromMeta(meta, documentText = '', now = new Date()) {
  const start = parseDayMonth(meta?.start);
  const end = parseDayMonth(meta?.end);
  if (!start || !end) return [];

  const startYear = inferYear(documentText, start.month, now);
  let endYear = startYear;
  if (end.month < start.month || (end.month === start.month && end.day < start.day)) endYear += 1;

  const startDate = new Date(Date.UTC(startYear, start.month - 1, start.day));
  const endDate = new Date(Date.UTC(endYear, end.month - 1, end.day));
  // Не принимаем невозможные даты из заголовка PDF (например, 31.02).
  if (startDate.getUTCMonth() !== start.month - 1 || startDate.getUTCDate() !== start.day) return [];
  if (endDate.getUTCMonth() !== end.month - 1 || endDate.getUTCDate() !== end.day) return [];
  const span = Math.round((endDate - startDate) / 86400000) + 1;
  if (span < 1 || span > 7) return [];

  return Array.from({ length: span }, (_, index) => {
    const date = new Date(startDate.getTime() + index * 86400000);
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
  });
}

export function assignWeekDatesToBlocks(blocks, meta, documentText = '', now = new Date()) {
  const dates = weekDatesFromMeta(meta, documentText, now);
  if (!Array.isArray(blocks) || dates.length !== blocks.length) return false;
  blocks.forEach((block, index) => {
    block.date = dates[index];
    block.day = dayNameFromIso(dates[index]);
  });
  return true;
}

export function dayNameFromIso(iso) {
  const match = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  return DAY_NAMES[(date.getUTCDay() + 6) % 7] || null;
}

const normalized = value => String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ru-RU');

/** Удаляет только полностью идентичные записи; параллельные разные предметы сохраняются. */
export function dedupeScheduleEntries(entries) {
  const unique = new Map();
  for (const entry of entries || []) {
    const key = [
      normalized(entry.group), normalized(entry.date), normalized(entry.day), normalized(entry.lesson),
      normalized(entry.time), normalized(entry.subject), normalized(entry.teacher), normalized(entry.room)
    ].join('\u001f');
    if (!unique.has(key)) unique.set(key, entry);
  }
  return [...unique.values()];
}
