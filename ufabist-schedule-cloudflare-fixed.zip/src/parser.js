import axios from 'axios';
import * as cheerio from 'cheerio';
import { assignWeekDatesToBlocks, dedupeScheduleEntries, weekDatesFromMeta } from './schedule-utils.js';

const SOURCE_URL = 'https://ufabist.ru/studentu/schedule/';
const HOST = 'ufabist.ru';
const USER_AGENT = 'UfaBIST-Schedule/2.4 (+https://ufabist.ru/studentu/schedule/; educational schedule reader)';
const REQUEST_TIMEOUT = 10_000;
const REQUEST_GAP = 400;
const MAX_ATTEMPTS = 2;
const MAX_PDF_BYTES = 20 * 1024 * 1024;
const PDF_CACHE_TTL = 15 * 60 * 1000;
const PDF_CACHE_SIZE = 80;
const WEEK_RE = /(\d{1,2})\s*недел[яи](?:\s*\(\s*с\s*(\d{1,2}\.\d{1,2})\s*по\s*(\d{1,2}\.\d{1,2})\s*\))?/i;
const WEEK_START_RE = /(?:^|\s)(\d{1,2})\s*недел[яи](?:\s*\(\s*с\s*(\d{1,2}\.\d{1,2})\s*по\s*(\d{1,2}\.\d{1,2})\s*\))?/i;
const DAY_NAMES = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
const DAY_RE = /понедельник|вторник|среда|четверг|пятница|суббота|воскресенье/i;
const DATE_RE = /(\d{1,2})\.(\d{1,2})\.(\d{2,4})/;
const TIME_RE = /^\d{1,2}:\d{2}\s*[-–—]\s*\d{1,2}:\d{2}$/;
const GROUP_RE = /(?<![\p{L}\p{N}])([\p{L}]{2,8}-\d{1,2})(?![\p{L}\p{N}])/gu;
const RANGE_RE = /([\p{L}]{2,8})-(\d{1,2})\s*,\s*(\d{1,2})(?![\d:.])/gu;

let lastRequestAt = 0;
let requestQueue = Promise.resolve();
let pdfjsPromise;
const pageHtmlCache = new Map();
const pdfEntriesCache = new Map();
const http = axios.create({
  timeout: REQUEST_TIMEOUT,
  maxContentLength: MAX_PDF_BYTES,
  maxBodyLength: MAX_PDF_BYTES,
  headers: { 'User-Agent': USER_AGENT, Accept: 'text/html,application/pdf;q=0.9,*/*;q=0.7' },
  validateStatus: status => status >= 200 && status < 400
});

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const clean = value => String(value ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
export const canonicalGroup = value => clean(value).toLocaleUpperCase('ru-RU').replace(/\s+/g, '');

function absoluteUrl(value) {
  const url = new URL(value, SOURCE_URL);
  if (url.protocol !== 'https:' || url.hostname !== HOST) throw new Error(`Недопустимый адрес источника: ${url.hostname}`);
  return url.href;
}

function timeoutError() {
  return Object.assign(new Error('Источник расписания не ответил вовремя.'), { status: 504 });
}

async function request(url, responseType = 'text', { force = false, deadline = Infinity } = {}) {
  const safeUrl = absoluteUrl(url);
  const run = async () => {
    let lastError;
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
      const wait = REQUEST_GAP - (Date.now() - lastRequestAt);
      if (wait > 0) await sleep(wait);
      const remaining = deadline - Date.now();
      if (remaining < 1500) throw lastError || timeoutError();
      const limit = Math.min(REQUEST_TIMEOUT, remaining);
      lastRequestAt = Date.now();
      try {
        const response = await http.get(safeUrl, {
          responseType, timeout: limit, signal: AbortSignal.timeout(limit + 500),
          headers: force ? { 'Cache-Control': 'no-cache' } : {}
        });
        return response.data;
      } catch (error) {
        lastError = error;
        if (error.response && error.response.status < 500) break;
        if (attempt < MAX_ATTEMPTS - 1) await sleep(400);
      }
    }
    throw lastError || new Error('Источник недоступен');
  };
  const result = requestQueue.then(run, run);
  requestQueue = result.then(() => undefined, () => undefined);
  return result;
}

async function getPage(url, { force = false, deadline } = {}) {
  const key = absoluteUrl(url);
  const cached = pageHtmlCache.get(key);
  if (!force && cached && Date.now() - cached.at < 10 * 60 * 1000) return cached.html;
  const html = await request(key, 'text', { force, deadline });
  pageHtmlCache.set(key, { html, at: Date.now() });
  return html;
}

async function getPdfJs() {
  if (!pdfjsPromise) {
    pdfjsPromise = (async () => {
      const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
      // Явный импорт pdf worker: GitHub Actions запускает парсер в обычном Node.js runner.
      globalThis.pdfjsWorker ||= await import('pdfjs-dist/legacy/build/pdf.worker.mjs');
      return pdfjs;
    })().catch(error => {
      pdfjsPromise = undefined;
      throw new Error(`Не удалось загрузить pdfjs-dist: ${error.message}`);
    });
  }
  return pdfjsPromise;
}

function collectProgramPages(html) {
  const $ = cheerio.load(html);
  const pages = [];
  $('a[href]').each((_, element) => {
    const title = clean($(element).text());
    if (!/^\d{2}\.\d{2}\.\d{2}\s+/.test(title)) return;
    try {
      const url = absoluteUrl($(element).attr('href'));
      if (url !== SOURCE_URL) pages.push({ title, url });
    } catch { /* внешние ссылки пропускаем */ }
  });
  return [...new Map(pages.map(page => [page.url, page])).values()];
}

/** Возвращает коды групп в написании источника (например «ИСДк-21»), без дублей. */
function expandGroupCodes(text) {
  const value = clean(text);
  const found = new Map();
  const add = code => { const key = canonicalGroup(code); if (!found.has(key)) found.set(key, code.replace(/\s+/g, '')); };
  for (const match of value.matchAll(RANGE_RE)) { add(`${match[1]}-${match[2]}`); add(`${match[1]}-${match[3]}`); }
  for (const match of value.matchAll(GROUP_RE)) add(match[1]);
  return [...found.values()];
}

function nearbyWeekCaption($, element) {
  const matches = [];
  const add = value => {
    const text = clean(value);
    if (text && text.length <= 240 && WEEK_START_RE.test(text)) matches.push(text);
  };

  // На реальных страницах БИСТ заголовок недели часто находится НЕ внутри <a> и
  // даже не в том же <p>, а отдельным предыдущим h3/h4. Раньше читался только
  // parent(anchor).text(), поэтому даты диапазона терялись, а parser переходил
  // к ненадёжным координатам вертикальных подписей PDF.
  let node = $(element);
  add(node.parent().text());
  add(node.text());
  for (let depth = 0; depth < 6; depth += 1) {
    const parent = node.parent();
    if (!parent.length) break;
    for (const sibling of node.prevAll().toArray()) {
      const text = clean($(sibling).text());
      add(text);
      if (matches.length) return matches[0];
    }
    add(parent.text());
    if (matches.length) return matches[0];
    node = parent;
  }
  return matches[0] || '';
}

function extractPdfLinks($, pageUrl) {
  const links = [];
  $('a[href]').each((_, element) => {
    const href = $(element).attr('href');
    if (!href || !/\.pdf(?:$|[?#])/i.test(href)) return;
    let url;
    try { url = absoluteUrl(href); } catch { return; }
    const text = clean($(element).text());
    // Сначала ищем подпись недели и диапазон дат рядом с PDF-ссылкой, включая
    // предыдущий h3/h4. Только затем используем номер недели из имени PDF.
    const caption = nearbyWeekCaption($, element);
    let fileName = '';
    try { fileName = decodeURIComponent(url.split('/').pop()); } catch { fileName = url; }
    const excluded = /сесси|аттестац|практик/i.test(caption || text) || /(?:УП|ПП|ПА)[-.]/i.test(fileName);
    const byCaption = !excluded ? caption.match(WEEK_START_RE) : null;
    const byFile = !byCaption && !excluded ? fileName.match(/-(\d{1,2})-нед\.pdf$/i) : null;
    const week = byCaption ? Number(byCaption[1]) : byFile ? Number(byFile[1]) : null;
    links.push({
      url, text, groups: expandGroupCodes(text), pageUrl,
      week,
      label: week ? `${week} неделя` : text,
      start: byCaption?.[2] || null,
      end: byCaption?.[3] || null
    });
  });
  const unique = new Map();
  for (const link of links) {
    const known = unique.get(link.url);
    if (!known) { unique.set(link.url, link); continue; }
    known.groups = [...new Map([...known.groups, ...link.groups].map(code => [canonicalGroup(code), code])).values()];
  }
  return [...unique.values()];
}

/** Быстрый каталог: группы берутся из подписей PDF-ссылок, сами PDF не скачиваются. */
export async function discoverCatalog({ force = false, deadline = Infinity, previous = null } = {}) {
  const indexHtml = await getPage(SOURCE_URL, { force, deadline });
  const programPages = collectProgramPages(indexHtml);
  if (!programPages.length) throw new Error('На странице расписания не найдены страницы направлений.');

  const catalog = new Map();
  const errors = [];
  for (const page of programPages) {
    try {
      const html = await getPage(page.url, { force, deadline });
      const $ = cheerio.load(html);
      for (const link of extractPdfLinks($, page.url)) {
        for (const name of link.groups) {
          const key = canonicalGroup(name);
          const existing = catalog.get(key) || { name, program: page.title, pageUrl: page.url, weekLinks: [] };
          if (link.week && !existing.weekLinks.some(item => item.url === link.url)) {
            existing.weekLinks.push({ url: link.url, week: link.week, label: link.label, start: link.start, end: link.end });
          }
          catalog.set(key, existing);
        }
      }
    } catch (error) {
      errors.push({ page: page.url, message: String(error.message || error).slice(0, 180) });
      // Страница недоступна: сохраняем группы этого направления из последнего успешного каталога, а не теряем их.
      for (const group of previous?.groups || []) {
        if (group.pageUrl === page.url && !catalog.has(canonicalGroup(group.name))) catalog.set(canonicalGroup(group.name), group);
      }
    }
  }

  const groups = [...catalog.values()]
    .map(group => ({ ...group, weekLinks: [...(group.weekLinks || [])].sort((a, b) => a.week - b.week) }))
    .sort((a, b) => a.name.localeCompare(b.name, 'ru'));
  if (!groups.length) {
    const detail = errors.length ? errors.map(item => item.message).join('; ') : 'На страницах направлений не найдены коды групп в подписях расписаний.';
    throw new Error(`Каталог пуст. ${detail}`);
  }
  return { source: SOURCE_URL, updatedAt: new Date().toISOString(), groups, programPages, errors, partial: errors.length > 0 };
}

function itemBounds(item) {
  const [a = 1, b = 0, c = 0, d = 1, x = 0, y = 0] = item.transform || [];
  const rotated = Math.abs(b) > 0.2 || Math.abs(c) > 0.2;
  const size = Math.max(Math.hypot(a, b), Math.hypot(c, d), 1);
  return { x, y, width: item.width || 0, height: size, rotated, up: b > 0, str: item.str, text: clean(item.str) };
}

/**
 * Часть PDF (например ПСД) хранит таблицу повёрнутой на 90°: основной текст идёт вдоль оси Y.
 * Переводим координаты в «читаемую» систему, чтобы остальной разбор был одинаковым для всех файлов.
 */
function normalizeOrientation(items, pageWidth, pageHeight) {
  const up = items.filter(item => item.rotated && item.up).length;
  const down = items.filter(item => item.rotated && !item.up).length;
  if (Math.max(up, down) <= items.length / 2) return { items, width: pageWidth, height: pageHeight };
  const dominantUp = up >= down;
  const mapped = items.map(item => {
    const sameAsDominant = item.rotated && item.up === dominantUp;
    const x = dominantUp ? item.y : pageHeight - item.y;
    const y = dominantUp ? pageWidth - item.x : item.x;
    return { ...item, x, y, rotated: !sameAsDominant, up: sameAsDominant ? true : dominantUp ? false : true };
  });
  return { items: mapped, width: pageHeight, height: pageWidth };
}

/** Склеивает фрагменты pdf.js в строки: PDF режет текст на куски по 1–5 символов. */
function buildRuns(items, maxGap) {
  const sorted = items.filter(item => !item.rotated).sort((a, b) => b.y - a.y);
  const lines = [];
  for (const item of sorted) {
    const line = lines.find(candidate => Math.abs(candidate.y - item.y) <= 2.5);
    if (line) line.items.push(item); else lines.push({ y: item.y, items: [item] });
  }
  const runs = [];
  for (const line of lines.sort((a, b) => b.y - a.y)) {
    line.items.sort((a, b) => a.x - b.x);
    let run = null;
    for (const item of line.items) {
      const gap = run ? item.x - run.end : Infinity;
      if (run && gap <= maxGap) {
        const needsSpace = gap > item.height * 0.18 && !/\s$/.test(run.text) && !/^\s/.test(item.str);
        run.text += (needsSpace ? ' ' : '') + item.str;
        run.end = Math.max(run.end, item.x + item.width);
      } else {
        run = { x: item.x, y: line.y, end: item.x + item.width, text: item.str, height: item.height };
        runs.push(run);
      }
    }
  }
  return runs.map(run => ({ ...run, text: clean(run.text), width: run.end - run.x })).filter(run => run.text);
}

function parseDate(text) {
  const match = text.match(DATE_RE);
  if (!match) return null;
  const year = Number(match[3].length === 2 ? `20${match[3]}` : match[3]);
  return `${year}-${String(match[2]).padStart(2, '0')}-${String(match[1]).padStart(2, '0')}`;
}

function dayFromDate(iso) {
  if (!iso) return null;
  const [year, month, day] = iso.split('-').map(Number);
  return DAY_NAMES[(new Date(year, month - 1, day).getDay() + 6) % 7];
}

function parseCell(raw) {
  let text = clean(raw)
    .replace(/\s+([.,;:)])/g, '$1')
    .replace(/\(\s+/g, '(')
    .replace(/([^\s(])\(/g, '$1 (');
  if (!text || /^экзамен/i.test(text) || /^(?:зачёт|зачет)\s+с\s+\d/i.test(text)) return null;

  const roomMatch = text.match(/(?:^|\s)(с\/зал|спортзал|актовый\s+зал|\d{1,4}[а-яА-Я]?)\s*$/i);
  const room = roomMatch ? clean(roomMatch[1]) : null;
  if (roomMatch) text = clean(text.slice(0, roomMatch.index));

  const teachers = [...text.matchAll(/[А-ЯЁ][а-яё-]+\s+[А-ЯЁ]\.\s*[А-ЯЁ]\./gu)].map(match => clean(match[0]));
  for (const teacher of teachers) text = clean(text.replace(teacher, ''));
  text = text.replace(/^[,;\s]+|[,;\s]+$/g, '');
  if (!text) return null;
  return { subject: text, teacher: teachers.length ? [...new Set(teachers)].join(', ') : null, room };
}

function assignDayLabels(blocks, labels) {
  for (const block of blocks) block.label = [];
  for (const label of labels) {
    const center = label.y + (label.rotated ? (label.up ? label.width / 2 : -label.width / 2) : 0);
    let best = null;
    for (const block of blocks) {
      const distance = center >= block.bottom - 20 && center <= block.top + 20 ? Math.abs(center - (block.top + block.bottom) / 2) : Infinity;
      if (distance < (best?.distance ?? Infinity)) best = { block, distance };
    }
    if (best) best.block.label.push(label);
  }
}

async function parsePdf(buffer, meta) {
  const pdfjs = await getPdfJs();
  const document = await pdfjs.getDocument({
    data: new Uint8Array(buffer), useSystemFonts: true, isEvalSupported: false, disableFontFace: true, verbosity: 0
  }).promise;
  const entries = [];
  try {
    for (let pageNo = 1; pageNo <= document.numPages; pageNo += 1) {
      const page = await document.getPage(pageNo);
      try {
        // Координаты текста заданы в пространстве страницы (view), а не в повёрнутом viewport.
        const [x0, y0, x1, y1] = page.view;
        const content = await page.getTextContent();
        const { items: raw, width, height } = normalizeOrientation(
          content.items.filter(item => typeof item.str === 'string' && item.str.length).map(itemBounds),
          x1 - x0, y1 - y0);
        const items = raw.filter(item => item.text);
        const runs = buildRuns(raw, 5);

        const groupRuns = runs
          .filter(run => run.y > height * 0.55 && run.x > width * 0.12)
          .map(run => ({ ...run, groups: expandGroupCodes(run.text) }))
          .filter(run => run.groups.length);
        if (!groupRuns.length) continue;
        const headerTop = Math.max(...groupRuns.map(run => run.y));
        const headers = groupRuns.filter(run => run.y >= headerTop - 30)
          .map(run => ({ center: run.x + run.width / 2, bottom: run.y, groups: run.groups }))
          .sort((a, b) => a.center - b.center);

        const merged = [];
        for (const header of headers) {
          const last = merged.at(-1);
          if (last && header.center - last.center < 30) {
            last.groups = [...new Map([...last.groups, ...header.groups].map(code => [canonicalGroup(code), code])).values()];
            last.bottom = Math.min(last.bottom, header.bottom);
          } else merged.push({ ...header });
        }

        const timeRuns = runs.filter(run => run.x < width * 0.4 && TIME_RE.test(run.text));
        const rows = timeRuns.map(time => {
          const number = runs.filter(run => run.x < time.x && /^\d{1,2}$/.test(run.text) && Math.abs(run.y - time.y) < 6)
            .sort((a, b) => Math.abs(a.y - time.y) - Math.abs(b.y - time.y))[0];
          return number ? { y: time.y, lesson: Number(number.text), time: time.text.replace(/\s/g, '') } : null;
        }).filter(Boolean).sort((a, b) => b.y - a.y);
        if (!rows.length) continue;

        const timeRight = Math.max(...timeRuns.map(run => run.x + run.width)) + 2;
        const columns = merged.map((header, index) => ({
          groups: header.groups,
          left: index === 0 ? timeRight : (merged[index - 1].center + header.center) / 2,
          right: index === merged.length - 1 ? width : (header.center + merged[index + 1].center) / 2
        }));
        const bodyTop = Math.min(...merged.map(header => header.bottom)) - 2;

        const blocks = [];
        for (const row of rows) {
          const current = blocks.at(-1);
          if (!current || row.lesson <= current.rows.at(-1).lesson) blocks.push({ rows: [row] }); else current.rows.push(row);
        }
        for (const block of blocks) {
          block.top = Math.max(...block.rows.map(row => row.y));
          block.bottom = Math.min(...block.rows.map(row => row.y));
        }
        // Строка-пояснение под шапкой («с 1-16 неделю (с 01.09 по 19.12.26г.)») не является занятием.
        const noteLines = new Set();
        for (const item of items) {
          if (item.rotated || item.y >= bodyTop || item.y <= rows[0].y + 6) continue;
          const line = items.filter(other => !other.rotated && Math.abs(other.y - item.y) <= 2.5).map(other => other.text).join(' ');
          if (/недел/i.test(line)) noteLines.add(Math.round(item.y));
        }
        const isNote = item => [...noteLines].some(y => Math.abs(y - item.y) <= 2.5);
        assignDayLabels(blocks, items.filter(item => (DAY_RE.test(item.text) || DATE_RE.test(item.text)) && !isNote(item)));
        const pageText = items.map(item => item.text).join(' ');
        // PDF на сайте содержит отдельные блоки дней сверху вниз и диапазон недели
        // в заголовке-соседе PDF-ссылки. Для одностраничных недельных таблиц число
        // блоков обязано совпадать с числом дат. Иначе не публикуем сомнительную
        // группировку (например, все пары под понедельником), а сохраняем last-good.
        const expectedWeekDates = weekDatesFromMeta(meta, pageText);
        if (document.numPages === 1 && expectedWeekDates.length && blocks.length !== expectedWeekDates.length) {
          throw new Error(`Не удалось разделить дни в PDF недели ${meta.week}: найдено блоков ${blocks.length}, ожидалось ${expectedWeekDates.length}. Предыдущий кэш не будет заменён.`);
        }
        const datesAssignedByWeekRange = assignWeekDatesToBlocks(blocks, meta, pageText);
        for (const block of blocks) {
          const text = block.label.sort((a, b) => b.y - a.y).map(label => label.text).join(' ');
          if (!datesAssignedByWeekRange) {
            block.date = parseDate(text);
            block.day = DAY_NAMES.find(name => text.toLocaleLowerCase('ru-RU').includes(name.toLocaleLowerCase('ru-RU'))) || dayFromDate(block.date);
          }
          for (const row of block.rows) row.block = block;
        }

        // Слова целиком (а не отдельные фрагменты pdf.js) привязываются к колонке по центру: иначе первая буква
        // слова, стоящая у границы колонок, уходит в соседнюю ячейку.
        const bodyItems = items.filter(item => !item.rotated && item.y < bodyTop
          && ![...noteLines].some(y => Math.abs(y - item.y) <= 2.5));
        const cells = new Map();
        for (const run of buildRuns(bodyItems.map(item => ({ ...item })), 6)) {
          const centerX = run.x + run.width / 2;
          const columnIndex = columns.findIndex(column => centerX >= column.left && centerX < column.right);
          if (columnIndex < 0) continue;
          const row = rows.reduce((best, candidate) => (Math.abs(candidate.y - run.y) < Math.abs(best.y - run.y) ? candidate : best));
          if (Math.abs(row.y - run.y) > 20) continue;
          const key = `${columnIndex}:${rows.indexOf(row)}`;
          if (!cells.has(key)) cells.set(key, { column: columns[columnIndex], row, runs: [] });
          cells.get(key).runs.push(run);
        }

        for (const { column, row, runs: cellRuns } of cells.values()) {
          const text = cellRuns.sort((x, y) => y.y - x.y || x.x - y.x).map(run => run.text).join(' ');
          const cell = parseCell(text);
          if (!cell) continue;
          for (const group of column.groups) {
            entries.push({
              group, day: row.block.day, date: row.block.date, lesson: row.lesson, time: row.time, ...cell,
              week: meta.week, weekLabel: meta.label, sourceUrl: meta.url
            });
          }
        }
      } finally {
        page.cleanup();
      }
    }
  } finally {
    await document.destroy();
  }
  return entries;
}

async function getPdfEntries(link, options) {
  const cached = pdfEntriesCache.get(link.url);
  if (!options.force && cached && Date.now() - cached.at < PDF_CACHE_TTL) return cached.entries;
  const pdf = await request(link.url, 'arraybuffer', options);
  const entries = await parsePdf(pdf, link);
  pdfEntriesCache.set(link.url, { entries, at: Date.now() });
  while (pdfEntriesCache.size > PDF_CACHE_SIZE) pdfEntriesCache.delete(pdfEntriesCache.keys().next().value);
  return entries;
}

/** Расписание одной группы: скачиваются только недельные PDF её направления. */
export async function getGroupSchedule(groupName, catalog, { force = false, deadline = Infinity } = {}) {
  const target = canonicalGroup(groupName);
  const group = catalog.groups.find(item => canonicalGroup(item.name) === target);
  if (!group) throw Object.assign(new Error('Группа не найдена в каталоге источника.'), { status: 404 });

  const page = await getPage(group.pageUrl, { force, deadline });
  const $ = cheerio.load(page);
  const known = new Set((group.weekLinks || []).map(item => item.url));
  const links = extractPdfLinks($, group.pageUrl).filter(link =>
    link.week && (link.groups.some(code => canonicalGroup(code) === target) || known.has(link.url) || !link.groups.length));
  if (!links.length) {
    const other = extractPdfLinks($, group.pageUrl).find(link =>
      !/Выписка|лиценз/i.test(link.text) && link.groups.some(code => canonicalGroup(code) === target));
    const hint = other ? ` Опубликован только PDF-скан без текстового слоя (сессия или семестр), его нельзя разобрать автоматически: ${other.url}` : '';
    throw Object.assign(new Error(`Для группы ${group.name} на сайте нет недельных PDF с текстовым расписанием.${hint}`), { status: 404 });
  }

  const weeks = [];
  const errors = [];
  for (const link of links) {
    try {
      const parsed = await getPdfEntries(link, { force, deadline });
      const entries = parsed.filter(item => canonicalGroup(item.group) === target);
      if (!entries.length) {
        errors.push(`${link.label}: для группы нет занятий в таблице PDF`);
        continue;
      }
      const uniqueEntries = dedupeScheduleEntries(entries);
      weeks.push({
        number: link.week, label: link.label, start: link.start, end: link.end, pdfUrl: link.url, program: group.program,
        entries: uniqueEntries.sort((a, b) => (a.date || '').localeCompare(b.date || '') || a.lesson - b.lesson || String(a.time || '').localeCompare(String(b.time || '')))
      });
    } catch (error) {
      errors.push(`${link.label}: ${String(error.message || error).slice(0, 160)}`);
    }
  }
  if (!weeks.length) throw Object.assign(new Error(`Не удалось извлечь пары для ${group.name}. ${errors.join('; ') || 'Проверь формат PDF.'}`), { status: 502 });
  return { name: group.name, weeks: weeks.sort((a, b) => a.number - b.number), updatedAt: new Date().toISOString(), errors };
}

/** Проверка доступности источника для /api/health. */
export async function probeSource(timeoutMs = 4000) {
  const startedAt = Date.now();
  try {
    const response = await axios.head(SOURCE_URL, {
      timeout: timeoutMs, signal: AbortSignal.timeout(timeoutMs + 300),
      headers: { 'User-Agent': USER_AGENT }, validateStatus: () => true, maxRedirects: 3
    });
    return { reachable: response.status < 500, status: response.status, latencyMs: Date.now() - startedAt };
  } catch (error) {
    return { reachable: false, status: null, latencyMs: Date.now() - startedAt, error: String(error.code || error.message).slice(0, 120) };
  }
}

export { SOURCE_URL };
