const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = 120;
const CACHE_TTL_SECONDS = 60;
const rateBuckets = new Map();

const json = (payload, status = 200) => new Response(JSON.stringify(payload), {
  status,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  }
});

const canonical = value => String(value ?? '').normalize('NFKC').toLocaleUpperCase('ru-RU').replace(/\s+/g, '');
const groupId = value => [...new TextEncoder().encode(canonical(value))]
  .map(byte => byte.toString(16).padStart(2, '0')).join('');

function allowed(request) {
  const now = Date.now();
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  let bucket = rateBuckets.get(ip);
  if (!bucket || now - bucket.startedAt >= RATE_WINDOW_MS) {
    bucket = { startedAt: now, count: 0 };
    rateBuckets.set(ip, bucket);
  }
  bucket.count += 1;
  if (rateBuckets.size > 500) {
    for (const [key, value] of rateBuckets) if (now - value.startedAt >= RATE_WINDOW_MS) rateBuckets.delete(key);
  }
  return bucket.count <= RATE_LIMIT;
}

async function readRepositoryJson(request, env, file) {
  const cache = caches.default;
  const cacheKey = new Request(new URL(`/__schedule_data_cache/${file}`, request.url).toString());
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();

  const owner = env.GITHUB_OWNER || 'cuprooo14-glitch';
  const repo = env.GITHUB_REPO || 'ufabist';
  const branch = env.GITHUB_BRANCH || 'main';
  const url = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/public/data/${file}`;
  const response = await fetch(url, {
    headers: { Accept: 'application/json', 'User-Agent': 'UfaBIST-Schedule-Worker/2.4' },
    cf: { cacheTtl: CACHE_TTL_SECONDS, cacheEverything: true }
  });
  if (!response.ok) {
    throw new Error(response.status === 404
      ? 'Данные ещё не созданы. Запусти GitHub Actions → Sync schedule → Run workflow.'
      : `Хранилище расписания вернуло HTTP ${response.status}.`);
  }
  const payload = await response.json();
  const copy = new Response(JSON.stringify(payload), {
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': `public, max-age=${CACHE_TTL_SECONDS}` }
  });
  await cache.put(cacheKey, copy);
  return payload;
}

async function health(request, env) {
  try {
    const [catalog, metadata] = await Promise.all([
      readRepositoryJson(request, env, 'catalog.json'),
      readRepositoryJson(request, env, 'metadata.json')
    ]);
    const age = Date.now() - Date.parse(metadata.updatedAt || '');
    const stale = !Number.isFinite(age) || age > 24 * 60 * 60 * 1000;
    return json({
      ok: Array.isArray(catalog.groups) && catalog.groups.length > 0,
      cacheAvailable: Array.isArray(catalog.groups) && catalog.groups.length > 0,
      status: metadata.partial || stale ? 'degraded' : 'ok',
      service: 'ufabist-schedule',
      groupCount: catalog.groups?.length || 0,
      updatedAt: metadata.updatedAt || catalog.updatedAt || null,
      stale,
      partial: Boolean(metadata.partial),
      errors: metadata.errors || []
    }, Array.isArray(catalog.groups) && catalog.groups.length ? 200 : 503);
  } catch (error) {
    return json({ ok: false, status: 'down', service: 'ufabist-schedule', error: String(error.message || error) }, 503);
  }
}

async function refresh(request, env) {
  const token = env.GITHUB_ACTIONS_TOKEN;
  if (token) {
    const owner = env.GITHUB_OWNER || 'cuprooo14-glitch';
    const repo = env.GITHUB_REPO || 'ufabist';
    const branch = env.GITHUB_BRANCH || 'main';
    let response;
    try {
      response = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/workflows/sync-schedule.yml/dispatches`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
          'Content-Type': 'application/json',
          'User-Agent': 'UfaBIST-Schedule-Worker'
        },
        body: JSON.stringify({ ref: branch }),
        signal: AbortSignal.timeout(8_000)
      });
    } catch {
      return json({ success: false, error: 'GitHub Actions сейчас недоступен. Последнее сохранённое расписание не изменено.' }, 502);
    }
    if (!response.ok) return json({ success: false, error: `Не удалось запустить синхронизацию GitHub Actions (HTTP ${response.status}).` }, 502);
    return json({ success: true, queued: true, message: 'Обновление запущено. Новые данные появятся после завершения синхронизации.' }, 202);
  }
  return json({
    success: true,
    queued: false,
    message: 'Показаны последние сохранённые данные. Автоматическая синхронизация выполняется каждые 6 часов. Для немедленного запуска открой GitHub → Actions → Sync schedule → Run workflow.'
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    if (!allowed(request)) return json({ error: 'Слишком много запросов. Попробуй позже.' }, 429);

    if (url.pathname === '/api/health' && request.method === 'GET') return health(request, env);
    if (url.pathname === '/api/groups' && request.method === 'GET') {
      try {
        const [catalog, metadata] = await Promise.all([
          readRepositoryJson(request, env, 'catalog.json'),
          readRepositoryJson(request, env, 'metadata.json')
        ]);
        const age = Date.now() - Date.parse(metadata.updatedAt || '');
        return json({
          groups: catalog.groups || [],
          updatedAt: metadata.updatedAt || catalog.updatedAt || null,
          stale: !Number.isFinite(age) || age > 24 * 60 * 60 * 1000 || (catalog.groups || []).some(group => group.stale),
          partial: Boolean(metadata.partial),
          source: catalog.source || 'https://ufabist.ru/studentu/schedule/',
          lastError: metadata.errors?.[0]?.message || null
        });
      } catch (error) {
        return json({ error: 'Не удалось загрузить каталог групп.', detail: String(error.message || error) }, 503);
      }
    }

    if (url.pathname === '/api/refresh' && request.method === 'POST') return refresh(request, env);

    if (url.pathname.startsWith('/api/groups/') && request.method === 'GET') {
      let name;
      try { name = decodeURIComponent(url.pathname.slice('/api/groups/'.length)); }
      catch { return json({ error: 'Некорректное название группы.' }, 400); }
      if (!name || name.length > 40 || !/^[\p{L}\p{N} -]+$/u.test(name)) return json({ error: 'Некорректное название группы.' }, 400);
      try {
        const catalog = await readRepositoryJson(request, env, 'catalog.json');
        const match = (catalog.groups || []).find(group => canonical(group.name) === canonical(name));
        if (!match) return json({ error: 'Группа не найдена в каталоге БИСТ.' }, 404);
        const schedule = await readRepositoryJson(request, env, `schedules/${match.id || groupId(match.name)}.json`);
        const metadata = await readRepositoryJson(request, env, 'metadata.json');
        const age = Date.now() - Date.parse(schedule.updatedAt || metadata.updatedAt || '');
        return json({
          group: { name: schedule.name || match.name, weeks: schedule.weeks || [] },
          updatedAt: schedule.updatedAt || metadata.updatedAt || null,
          stale: Boolean(schedule.stale || match.stale) || !Number.isFinite(age) || age > 24 * 60 * 60 * 1000,
          errors: schedule.errors || []
        });
      } catch (error) {
        return json({ error: `Не удалось загрузить расписание группы ${name}.`, detail: String(error.message || error) }, 503);
      }
    }

    return json({ error: 'API-маршрут не найден.' }, 404);
  }
};
