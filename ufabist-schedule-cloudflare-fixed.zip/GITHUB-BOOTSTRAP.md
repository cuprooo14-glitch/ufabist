# Как загрузить весь проект в GitHub с iPhone одним ZIP

GitHub не распаковывает ZIP при обычной загрузке файла. Чтобы не создавать десятки папок вручную, добавь в пустой репозиторий одноразовый workflow, затем загрузи ZIP. Workflow распакует его в корень репозитория и сохранит файлы.

## 1. Создай файл workflow

В репозитории `cuprooo14-glitch/ufabist` открой **Add file → Create new file**.

Имя файла (вставь полностью):

```text
.github/workflows/install-from-zip.yml
```

Вставь содержимое:

```yaml
name: Install project from ZIP

on:
  push:
    paths:
      - 'ufabist-schedule-cloudflare-fixed.zip'
  workflow_dispatch:

permissions:
  contents: write

jobs:
  unpack:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Check uploaded archive
        id: archive
        shell: bash
        run: |
          if [ -f ufabist-schedule-cloudflare-fixed.zip ]; then
            echo "present=true" >> "$GITHUB_OUTPUT"
          else
            echo "present=false" >> "$GITHUB_OUTPUT"
          fi

      - name: Unpack project into repository root
        if: steps.archive.outputs.present == 'true'
        run: |
          mkdir -p /tmp/ufabist-project
          unzip -q -o ufabist-schedule-cloudflare-fixed.zip -d /tmp/ufabist-project
          cp -a /tmp/ufabist-project/. .
          rm -f ufabist-schedule-cloudflare-fixed.zip

      - name: Commit extracted project
        if: steps.archive.outputs.present == 'true'
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
          git add -A
          if git diff --cached --quiet; then
            echo "No files to commit."
            exit 0
          fi
          git commit -m "Install UfaBIST Cloudflare project"
          git push
```

Нажми **Commit changes**.

## 2. Загрузи ZIP

Вернись в корень репозитория → **Add file → Upload files**. Выбери `ufabist-schedule-cloudflare-fixed.zip` из приложения «Файлы» на iPhone и нажми **Commit changes**.

## 3. Дождись распаковки

Открой вкладку **Actions** → workflow **Install project from ZIP**. Дождись зелёной галочки. Он создаст все папки и файлы проекта в корне репозитория и удалит загруженный ZIP.

После этого должен появиться `wrangler.jsonc`, `src/`, `public/`, `scripts/` и `.github/workflows/sync-schedule.yml`.

> Если workflow не может выполнить `git push`, открой Settings → Actions → General → Workflow permissions и включи **Read and write permissions**, затем повтори запуск.

## 4. Потом подключай Cloudflare

Только после распаковки подключай этот репозиторий в Workers Builds. Deploy command: `npx wrangler deploy`; Build command можно оставить пустым. Не создавай вручную переменную `CLOUDFLARE_API_TOKEN` — выбери автоматическое создание Cloudflare build token.
